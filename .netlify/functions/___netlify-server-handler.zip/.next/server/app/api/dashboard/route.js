var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__94b47f6b._.js")
R.c("server/chunks/[root-of-the-server]__23433c36._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__7e2ac0e0._.js")
R.c("server/chunks/[root-of-the-server]__2d227295._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_route_actions_310b0824.js")
R.m(60626)
module.exports=R.m(60626).exports
